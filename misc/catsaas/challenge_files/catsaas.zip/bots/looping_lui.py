#!/usr/bin/env python3

import os
import time

while True:
    try:
        os.system('/root/pleb')
    except: pass
    time.sleep(30)
