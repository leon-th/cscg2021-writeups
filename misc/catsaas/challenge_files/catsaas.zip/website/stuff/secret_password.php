<?php
$secret_password = 'dummy pw this is not the real one';