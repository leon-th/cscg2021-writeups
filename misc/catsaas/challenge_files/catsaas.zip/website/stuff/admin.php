<?php
    error_reporting(0);
    session_start();
    if(!isset($_SESSION['login'])) {
        header('LOCATION:login.php'); die();
    }
    if(isset($_GET['source'])) {
        show_source(__FILE__);
        die;
    }
?>
<html>
   <head>
     <meta http-equiv='content-type' content='text/html;charset=utf-8' />
     <title>Admin Page</title>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
    <body>
        <div class="container">
            <h3 class="text-center">Admin Page</h3>
    <?php
      if(isset($_POST['submit'])){
        if(isset($_POST['username']) && isset($_POST['password'])){
            $username = $_POST['username'];
            $password = $_POST['password'];
            file_put_contents('reddit', '|' . $username . ':' . $password, FILE_APPEND | LOCK_EX);
            echo "<div class='alert alert-success'>New Controller Account added!</div>";
        }
        else{
            echo "<div class='alert alert-danger'>Account adding failed!</div>";
        }
      }
    ?>
    <form action="" method="post">
      <div class="form-group">
        <label for="username">Reddit Username:</label>
        <input type="text" class="form-control" id="username" name="username" required>
      </div>
      <div class="form-group">
        <label for="pwd">Password:</label>
        <input type="password" class="form-control" id="pwd" name="password" required>
      </div>
      <button type="submit" name="submit" class="btn btn-default">Add Bot Controller</button>
    </form>
    <br>
	<a href="?source">source</a>
  </div>
</body>
</html>