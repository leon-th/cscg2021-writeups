<?php
error_reporting(0);
# Can you perform a local file inclusion?
# I think some filenames behave weirdly in PHP sometimes? :thonk: Pls fix

if($_GET['f']) {
    $f = basename($_GET['f']);
    if(file_exists($f)) die('hacking detected!');

    include $f;
}

show_source(__FILE__);
