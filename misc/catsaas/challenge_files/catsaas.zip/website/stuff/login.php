<?php
    error_reporting(0);
    session_start();
    if(isset($_SESSION['login'])) {
      header('Location: admin.php');
      die();
    }
    if(isset($_GET['source'])) {
        show_source(__FILE__);
        die;
    }
?>
<!DOCTYPE html>
<html>
   <head>
     <meta http-equiv='content-type' content='text/html;charset=utf-8' />
     <title>Login</title>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <?php
      if(isset($_POST['submit']) && isset($_POST['username']) && isset($_POST['password'])){
        $username = $_POST['username'];
        $password = $_POST['password'];
        require 'secret_password.php';
        if($username === 'admin' && $password === $secret_password){
          $_SESSION['login'] = true;
          echo "<meta http-equiv=\"refresh\" content=\"0;url=admin.php\">";
          die();
        } {
          echo "</head>\n<body>\n<div class=\"container\">\n<h3 class=\"text-center\">Login</h3>";
          echo "<div class='alert alert-danger'>Username and Password do not match.</div>";
        }
        
      }
      else{
          echo"</head>\n<body>\n<div class=\"container\">\n<h3 class=\"text-center\">Login</h3>";
      }
    ?>
    <form action="" method="post">
      <div class="form-group">
        <label for="username">Username:</label>
        <input type="text" class="form-control" id="username" name="username" required>
      </div>
      <div class="form-group">
        <label for="pwd">Password:</label>
        <input type="password" class="form-control" id="pwd" name="password" required>
      </div>
      <button type="submit" name="submit" class="btn btn-default">Login</button>
    </form>
    <br>
	<a href="?source">source</a>
  </div>
</body>
</html>